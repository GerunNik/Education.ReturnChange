﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Return_Change
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(bezahlen.Text) < Convert.ToDouble(bezahlt.Text))
            {
                double bezahlenD = Convert.ToDouble(bezahlen.Text);
                double bezahltD = Convert.ToDouble(bezahlt.Text);
                double zuruckGeld = bezahltD - bezahlenD;

                double Rp_5 = 0;
                double Rp_10 = 0;
                double Rp_20 = 0;
                double Rp_50 = 0;
                double Fr_1 = 0;
                double Fr_2 = 0;
                double Fr_5 = 0;
                double Fr_10 = 0;
                double Fr_20 = 0;
                double Fr_50 = 0;
                double Fr_100 = 0;
                double Fr_200 = 0;

                while (zuruckGeld > 200)
                {
                    zuruckGeld = zuruckGeld - 200;
                    Fr_200++;
                }

                Fr200.Text = Fr_200.ToString();

                while (zuruckGeld > 100)
                {
                    zuruckGeld = zuruckGeld - 100;
                    Fr_100++;
                    Fr100.Text = Fr_100.ToString();
                }
                while (zuruckGeld > 50)
                {
                    zuruckGeld = zuruckGeld - 50;
                    Fr_50++;
                    Fr50.Text = Fr_50.ToString();
                }
                while (zuruckGeld > 20)
                {
                    zuruckGeld = zuruckGeld - 20;
                    Fr_20++;
                    Fr20.Text = Fr_20.ToString();
                }
                while (zuruckGeld > 10)
                {
                    zuruckGeld = zuruckGeld - 10;
                    Fr_10++;
                    Fr10.Text = Fr_10.ToString();
                }
                while (zuruckGeld > 5)
                {
                    zuruckGeld = zuruckGeld - 5;
                    Fr_5++;
                    Fr5.Text = Fr_5.ToString();
                }
                while (zuruckGeld > 2)
                {
                    zuruckGeld = zuruckGeld - 2;
                    Fr_2++;
                    Fr2.Text = Fr_2.ToString();
                }
                while (zuruckGeld > 1)
                {
                    zuruckGeld = zuruckGeld - 1;
                    Fr_1++;
                    Fr1.Text = Fr_1.ToString();
                }
                while (zuruckGeld > 0.5)
                {
                    zuruckGeld = zuruckGeld - 0.5;
                    Rp_50++;
                    Rp50.Text = Rp_50.ToString();
                }
                while (zuruckGeld > 0.2)
                {
                    zuruckGeld = zuruckGeld - 0.2;
                    Rp_20++;
                    Rp20.Text = Rp_20.ToString();
                }
                while (zuruckGeld > 0.1)
                {
                    zuruckGeld = zuruckGeld - 0.1;
                    Rp_10++;
                    Rp10.Text = Rp_10.ToString();
                }
                while (zuruckGeld > 0.05)
                {
                    zuruckGeld = zuruckGeld - 0.05;
                    Rp_5++;
                    Rp5.Text = Rp_5.ToString();
                }
                if (zuruckGeld > 0.02)
                {
                    Rp_5++;
                    Rp5.Text = Rp_5.ToString();
                }
            }
            else
            {
            }
        }
    }
}
